var searchData=
[
  ['dialog',['Dialog',['../class_dialog.html#acfa2063f9f962d394c6a645b6e7e08d8',1,'Dialog']]],
  ['dotproduct',['dotProduct',['../classclass__point.html#a85c9ce254fa9a2ec73b9db7e5b36d9c7',1,'class_point']]]
];
