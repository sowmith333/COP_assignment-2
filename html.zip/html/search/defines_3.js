var searchData=
[
  ['size',['SIZE',['../main_8cpp.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;main.cpp'],['../main__new_8cpp.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;main_new.cpp']]]
];
