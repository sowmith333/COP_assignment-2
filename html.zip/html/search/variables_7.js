var searchData=
[
  ['x',['x',['../classclass__point.html#a80511a65b5587762afd356d3b9883bf8',1,'class_point']]],
  ['xy',['XY',['../classclass__2d.html#a2a37876f1fdbc7a916588c3358d85ee8',1,'class_2d']]]
];
