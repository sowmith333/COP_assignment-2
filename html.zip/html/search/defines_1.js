var searchData=
[
  ['factor',['FACTOR',['../main_8cpp.html#a63c7acef5369ac4e5fd5f852ee1720e0',1,'FACTOR():&#160;main.cpp'],['../main__new_8cpp.html#a63c7acef5369ac4e5fd5f852ee1720e0',1,'FACTOR():&#160;main_new.cpp']]]
];
