var searchData=
[
  ['y',['y',['../classclass__point.html#ac7f24ef017709ecf6a3179ccd4b921ef',1,'class_point']]],
  ['yz',['YZ',['../classclass__2d.html#ac6d8e138e7c05be126bd65382c6a8f3c',1,'class_2d']]]
];
