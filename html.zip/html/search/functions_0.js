var searchData=
[
  ['add_5fedge',['add_edge',['../classclass__face.html#aa0a56b108d625246555ac47d7d71d10a',1,'class_face::add_edge()'],['../classclass__plane.html#aa8f3da35e1f448001036b2cd350188d4',1,'class_plane::add_edge(class_line)'],['../classclass__plane.html#aa8f3da35e1f448001036b2cd350188d4',1,'class_plane::add_edge(class_line)']]],
  ['add_5fpoint',['add_point',['../classclass__plane.html#a412ca8d34fac90a24c4ff5e8b6580971',1,'class_plane::add_point(class_point)'],['../classclass__plane.html#a412ca8d34fac90a24c4ff5e8b6580971',1,'class_plane::add_point(class_point)']]],
  ['addvec',['addVec',['../classclass__point.html#a2f0ccde46a30906dbdfbd966852ac310',1,'class_point']]]
];
