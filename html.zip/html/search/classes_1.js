var searchData=
[
  ['dialog',['Dialog',['../class_dialog.html',1,'']]]
];
