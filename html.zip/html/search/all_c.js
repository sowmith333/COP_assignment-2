var searchData=
[
  ['second_5funitvec',['second_unitVec',['../classclass__point.html#ac3e08e0d8709c8a501bbb923c84600f8',1,'class_point']]],
  ['set_5fedges',['set_edges',['../classclass__plane.html#ab51204bd1213b3ad8ef498f51930b93d',1,'class_plane::set_edges(vector&lt; class_line &gt; a)'],['../classclass__plane.html#ab51204bd1213b3ad8ef498f51930b93d',1,'class_plane::set_edges(vector&lt; class_line &gt; a)']]],
  ['set_5fid',['set_id',['../classclass__line.html#af04730d51ac30b5a956bcb8ba9700cba',1,'class_line::set_id()'],['../classclass__plane.html#a6157d96081111f4a4c4085d9f3f2eba0',1,'class_plane::set_id(int a)'],['../classclass__plane.html#a6157d96081111f4a4c4085d9f3f2eba0',1,'class_plane::set_id(int a)'],['../classclass__point.html#a51e94de945f7c27ced0a7bb236bcbc6b',1,'class_point::set_id()']]],
  ['size',['SIZE',['../main_8cpp.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;main.cpp'],['../main__new_8cpp.html#a70ed59adcb4159ac551058053e649640',1,'SIZE():&#160;main_new.cpp']]]
];
