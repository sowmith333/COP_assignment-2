var searchData=
[
  ['lines',['lines',['../classclass__face.html#adafef89a4f4a850f39b388c4e8c017a3',1,'class_face']]]
];
