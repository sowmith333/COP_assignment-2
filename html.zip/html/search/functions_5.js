var searchData=
[
  ['get_5f3d',['get_3d',['../main_8cpp.html#aad5d6b1986777fe789ef1e66e9dce1a0',1,'get_3d():&#160;main.cpp'],['../main__new_8cpp.html#aad5d6b1986777fe789ef1e66e9dce1a0',1,'get_3d():&#160;main_new.cpp'],['../prob_8cpp.html#aad5d6b1986777fe789ef1e66e9dce1a0',1,'get_3d():&#160;prob.cpp']]],
  ['get_5fedges_5fshared',['get_edges_shared',['../classclass__plane.html#ac7f0697a758658c31961ea8a6a7dc812',1,'class_plane::get_edges_shared(int i)'],['../classclass__plane.html#ac7f0697a758658c31961ea8a6a7dc812',1,'class_plane::get_edges_shared(int i)']]],
  ['get_5ffaces',['get_faces',['../classclass__3d.html#a7ce58b8cd3aaef0cff49c3dabff67ae8',1,'class_3d']]],
  ['get_5ffin',['get_fin',['../classclass__line.html#a70df733a0df63c3604a362922fbe2cda',1,'class_line']]],
  ['get_5fid',['get_id',['../classclass__face.html#a3c8cd1e30cfd6407e8f5bc05d100858a',1,'class_face::get_id()'],['../classclass__line.html#ac48d402f627a111da5e8f07fbfb51bcf',1,'class_line::get_id()'],['../classclass__point.html#ac36257ee50c113fd2636c21ce8f274eb',1,'class_point::get_id()']]],
  ['get_5finit',['get_init',['../classclass__line.html#a23725c3578ca127f5f4d510374febba4',1,'class_line']]],
  ['get_5fith',['get_ith',['../classclass__plane.html#adf411530a880dc4109b1250975619b53',1,'class_plane::get_ith(int i)'],['../classclass__plane.html#adf411530a880dc4109b1250975619b53',1,'class_plane::get_ith(int i)']]],
  ['get_5flines',['get_lines',['../classclass__3d.html#ad4807f862def9a7bedc31a1e640436ad',1,'class_3d']]],
  ['get_5fnormal',['get_normal',['../classclass__plane.html#a3129f0b8cffaeb186a1e87fa27c0669b',1,'class_plane::get_normal()'],['../classclass__plane.html#ae629226f888173235dd618ebdcfacce1',1,'class_plane::get_normal()']]],
  ['get_5fpoints',['get_points',['../classclass__3d.html#a7c80cf739b8e1057afda3907abe03cc3',1,'class_3d']]],
  ['get_5fref',['get_ref',['../classclass__point.html#a6604614d9eabf91dbf882822c387243f',1,'class_point']]],
  ['get_5fx',['get_X',['../classclass__point.html#adfd1518aa1530d8b031a350f963db719',1,'class_point']]],
  ['get_5fxy_5flines',['get_xy_lines',['../classclass__2d.html#a4bd5e5180034e17b1a29f1176cf69742',1,'class_2d::get_xy_lines()'],['../classclass__2d.html#a4bd5e5180034e17b1a29f1176cf69742',1,'class_2d::get_xy_lines()']]],
  ['get_5fxy_5fpoints',['get_xy_points',['../classclass__2d.html#a3677ce3157547d5fb159cef57e1beed3',1,'class_2d::get_xy_points(string a, string b)'],['../classclass__2d.html#a3677ce3157547d5fb159cef57e1beed3',1,'class_2d::get_xy_points(string a, string b)']]],
  ['get_5fxz_5flines',['get_xz_lines',['../classclass__2d.html#a9dc8b46b91392b3e1f6a121c94a9fe84',1,'class_2d::get_xz_lines()'],['../classclass__2d.html#a9dc8b46b91392b3e1f6a121c94a9fe84',1,'class_2d::get_xz_lines()']]],
  ['get_5fxz_5fpoints',['get_xz_points',['../classclass__2d.html#a448ce1dee999534516d111aa7497d47d',1,'class_2d::get_xz_points()'],['../classclass__2d.html#a448ce1dee999534516d111aa7497d47d',1,'class_2d::get_xz_points()']]],
  ['get_5fy',['get_Y',['../classclass__point.html#ad39ac4c500e9812c4f507b3887214102',1,'class_point']]],
  ['get_5fyz_5flines',['get_yz_lines',['../classclass__2d.html#aea3e7f3c4fcffc73003d0c93bb92cf58',1,'class_2d::get_yz_lines()'],['../classclass__2d.html#aea3e7f3c4fcffc73003d0c93bb92cf58',1,'class_2d::get_yz_lines()']]],
  ['get_5fyz_5fpoints',['get_yz_points',['../classclass__2d.html#a9c42dc988fdb99dfb84e95625f86aa3a',1,'class_2d::get_yz_points()'],['../classclass__2d.html#a9c42dc988fdb99dfb84e95625f86aa3a',1,'class_2d::get_yz_points()']]],
  ['get_5fz',['get_Z',['../classclass__point.html#a2772a851fe6ed20b2090745793efc8ec',1,'class_point']]]
];
