var searchData=
[
  ['loadxyplane',['loadxyPlane',['../classclass__2d.html#a831d0ea2ce6c3b519602a35f8fc88d8f',1,'class_2d::loadxyPlane(string file1, string file2)'],['../classclass__2d.html#a963c02d2442102e5af58f6daedacfe2b',1,'class_2d::loadxyPlane(QString file1, QString file2)']]],
  ['loadyzplane',['loadyzPlane',['../classclass__2d.html#ac9c8783aea59b960946be41650ae2c17',1,'class_2d::loadyzPlane(string file1, string file2)'],['../classclass__2d.html#a9da2abf42707eb58fdcd05c3e95cac0a',1,'class_2d::loadyzPlane(QString file1, QString file2)']]],
  ['loadzxplane',['loadzxPlane',['../classclass__2d.html#a5ebf9a621ab8a375c3f05c764494b798',1,'class_2d::loadzxPlane(string file1, string file2)'],['../classclass__2d.html#adf16ff3467029bb85ec1d04625398985',1,'class_2d::loadzxPlane(QString file1, QString file2)']]]
];
