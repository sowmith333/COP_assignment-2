var searchData=
[
  ['_7edialog',['~Dialog',['../class_dialog.html#a2a1fe6ef28513eed13bfcd3a4da83ccb',1,'Dialog']]]
];
