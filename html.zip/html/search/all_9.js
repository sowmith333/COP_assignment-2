var searchData=
[
  ['nor',['nor',['../classclass__plane.html#aed25129f1149c3c93622597d5496b4a7',1,'class_plane']]],
  ['normalize',['normalize',['../classclass__point.html#a6184edf14eabd91d353de596f3e1700e',1,'class_point']]]
];
